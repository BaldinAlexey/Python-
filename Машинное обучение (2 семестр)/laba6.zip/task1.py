# ЛАБОРАТОРНАЯ РАБОТА №6 — Прогнозирование временных рядов

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import MinMaxScaler
import random

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

 
# 1. Загрузка данных
 
url = "https://raw.githubusercontent.com/zhouhaoyi/ETDataset/main/ETT-small/ETTh1.csv"

df = pd.read_csv(url, parse_dates=["date"], index_col="date")
series = df["OT"].values.reshape(-1, 1)

print("Размер данных:", series.shape)

 
# 2. Нормализация (ВАЖНО!)
 
scaler = MinMaxScaler()
train_size = int(len(series) * 0.7)

train_data = scaler.fit_transform(series[:train_size])
test_data = scaler.transform(series[train_size:])

 
# 3. Dataset
 
class TSDataset(Dataset):
    def __init__(self, data, L=96, H=24):
        self.data = torch.tensor(data, dtype=torch.float32)
        self.L = L
        self.H = H

    def __len__(self):
        return len(self.data) - self.L - self.H

    def __getitem__(self, idx):
        x = self.data[idx:idx+self.L]
        y = self.data[idx+self.L:idx+self.L+self.H].squeeze()
        return x, y

L = 96
H = 24

train_dataset = TSDataset(train_data, L, H)
test_dataset = TSDataset(test_data, L, H)

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=64)

 
# 4. Метрики
 
def mae(y_true, y_pred):
    return np.mean(np.abs(y_true - y_pred))

def rmse(y_true, y_pred):
    return np.sqrt(np.mean((y_true - y_pred)**2))

 
# 5. Наивные модели
 
def naive(window, H):
    return np.full(H, window[-1])

def roll_mean(window, H):
    return np.full(H, window.mean())

# Проверка baseline
test_sample = test_dataset[0][0].numpy().flatten()

print("\nNaive:", naive(test_sample, H)[:5])
print("Mean:", roll_mean(test_sample, H)[:5])

 
# 6. LSTM модель
 
class LSTMModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.lstm = nn.LSTM(1, 64, 2, batch_first=True)
        self.fc = nn.Linear(64, H)

    def forward(self, x):
        out, _ = self.lstm(x)
        return self.fc(out[:, -1])

model = LSTMModel().to(device)

criterion = nn.MSELoss()
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)

train_losses = []

 
# 7. Обучение LSTM
 
print("\nОбучение LSTM")

for epoch in range(10):
    model.train()
    total_loss = 0

    for x, y in train_loader:
        x, y = x.to(device), y.to(device)

        out = model(x)
        loss = criterion(out, y)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    avg_loss = total_loss / len(train_loader)
    train_losses.append(avg_loss)

    print(f"Epoch {epoch+1}, Loss={avg_loss:.4f}")

 
# 8. Оценка LSTM
 
model.eval()
y_true, y_pred = [], []

with torch.no_grad():
    for x, y in test_loader:
        x = x.to(device)
        pred = model(x).cpu().numpy()
        y_pred.extend(pred)
        y_true.extend(y.numpy())

y_true = np.array(y_true)
y_pred = np.array(y_pred)

print("\nLSTM MAE:", mae(y_true, y_pred))
print("LSTM RMSE:", rmse(y_true, y_pred))

 
# 9. Transformer модель
 
class TransformerModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.proj = nn.Linear(1, 64)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=64, nhead=4, batch_first=True
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=2)
        self.fc = nn.Linear(64 * L, H)

    def forward(self, x):
        x = self.proj(x)
        x = self.encoder(x)
        return self.fc(x.flatten(1))

model_t = TransformerModel().to(device)

optimizer = torch.optim.AdamW(model_t.parameters(), lr=1e-3)

 
# 10. Обучение Transformer
 
print("\nОбучение Transformer")

for epoch in range(10):
    model_t.train()
    total_loss = 0

    for x, y in train_loader:
        x, y = x.to(device), y.to(device)

        out = model_t(x)
        loss = criterion(out, y)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    print(f"Epoch {epoch+1}, Loss={total_loss/len(train_loader):.4f}")

 
# 11. Оценка Transformer
 
model_t.eval()
y_pred_t = []

with torch.no_grad():
    for x, _ in test_loader:
        x = x.to(device)
        pred = model_t(x).cpu().numpy()
        y_pred_t.extend(pred)

y_pred_t = np.array(y_pred_t)

print("\nTransformer MAE:", mae(y_true, y_pred_t))
print("Transformer RMSE:", rmse(y_true, y_pred_t))

 
# 12. График Loss
 
plt.plot(train_losses)
plt.title("LSTM Loss")
plt.show()

 
# 13. Визуализация прогнозов
 
plt.figure(figsize=(10,5))

for i in range(5):
    idx = random.randint(0, len(test_dataset)-1)
    x, y = test_dataset[idx]

    pred = model(x.unsqueeze(0).to(device)).detach().cpu().numpy()[0]

    plt.subplot(2,3,i+1)
    plt.plot(y.numpy(), label="True")
    plt.plot(pred, label="Pred")
    plt.legend()

plt.suptitle("Прогноз vs Реальность")
plt.show()