# ЛР1 — Линейная регрессия (Weather)

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 3D plotting
from mpl_toolkits.mplot3d import Axes3D

 
# 1. Загрузка данных

print("Загрузка датасета...")
df = pd.read_csv("weatherHistory.csv")

# Оставляем нужные признаки
df = df[[
"Temperature (C)",
"Humidity",
"Wind Speed (km/h)",
"Apparent Temperature (C)"
]]

df = df.dropna()

 
# 2. Модель №1 (простая)
# Температура + Влажность
X1 = df[["Temperature (C)", "Humidity"]]
y = df["Apparent Temperature (C)"]

X_train1, X_test1, y_train1, y_test1 = train_test_split(
X1, y, test_size=0.2, random_state=42
)

model1 = LinearRegression()
model1.fit(X_train1, y_train1)

pred1 = model1.predict(X_test1)

# Метрики
mae1 = mean_absolute_error(y_test1, pred1)
rmse1 = np.sqrt(mean_squared_error(y_test1, pred1))
r21 = r2_score(y_test1, pred1)

print("\n Модель 1 ")
print("MAE:", mae1)
print("RMSE:", rmse1)
print("R2:", r21)

 

# 3. Модель №2 (множественная)
# + Скорость ветра
X2 = df[[
"Temperature (C)",
"Humidity",
"Wind Speed (km/h)"
]]

X_train2, X_test2, y_train2, y_test2 = train_test_split(
X2, y, test_size=0.2, random_state=42
)

model2 = LinearRegression()
model2.fit(X_train2, y_train2)

pred2 = model2.predict(X_test2)

# Метрики

mae2 = mean_absolute_error(y_test2, pred2)
rmse2 = np.sqrt(mean_squared_error(y_test2, pred2))
r22 = r2_score(y_test2, pred2)

print("\n Модель 2 ")
print("MAE:", mae2)
print("RMSE:", rmse2)
print("R2:", r22)

 
# 4. Визуал
# Scatter + линия регрессии
plt.figure(figsize=(8,6))
sns.regplot(
x=X_test1["Temperature (C)"],
y=y_test1,
scatter_kws={"alpha":0.4},
line_kws={"color":"red"}
)
plt.title("Температура → Ощущаемая температура")
plt.show()

# Pairplot
sns.pairplot(
df.sample(2000)
)
plt.show()

# 3D график
fig = plt.figure(figsize=(9,7))
ax = fig.add_subplot(111, projection='3d')

sample = df.sample(1500)

ax.scatter(
sample["Temperature (C)"],
sample["Humidity"],
sample["Apparent Temperature (C)"],
alpha=0.4
)

ax.set_xlabel("Температура")
ax.set_ylabel("Влажность")
ax.set_zlabel("Ощущаемая температура")

plt.title("3D визуализация")
plt.show()


# 5. Консольный стенд
print("\n Тестовый стенд ")

while True:
    try:
        t = float(input("\nТемпература (или q для выхода): "))
        h = float(input("Влажность: "))
        w = float(input("Скорость ветра: "))

        pred_simple = model1.predict([[t, h]])[0]
        pred_multi = model2.predict([[t, h, w]])[0]

        print(f"\nПростая модель → {pred_simple:.2f} C")
        print(f"Множественная модель → {pred_multi:.2f} C")

    except:
        print("Выход")
        break
