import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.datasets import load_breast_cancer
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
 
# 2. Загрузка данных

data = load_breast_cancer()

X = data.data
y = data.target
feature_names = data.feature_names

print("Форма X:", X.shape)
print("Форма y:", y.shape)
print("Названия классов:", data.target_names)

# Создание DataFrame
df = pd.DataFrame(X, columns=feature_names)

print("\nПервые 5 строк:")
print(df.head())

print("\nСтатистика по признакам:")
print(df.describe())


 
# 3. Стандартизация
 

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
 
# 4. Реализация PCA вручную

def my_pca(X, K):
    # 1. Центрирование
    X_centered = X - X.mean(axis=0)
    
    # 2. Ковариационная матрица
    C = np.cov(X_centered, rowvar=False)
    
    # 3. Собственные значения и векторы
    eigvals, eigvecs = np.linalg.eig(C)
    
    # 4. Сортировка по убыванию
    sorted_indices = np.argsort(eigvals)[::-1]
    eigvals_sorted = eigvals[sorted_indices]
    eigvecs_sorted = eigvecs[:, sorted_indices]
    
    # 5. Выбор K компонент
    W_K = eigvecs_sorted[:, :K]
    
    # 6. Проекция данных
    Z = X_centered @ W_K
    
    return Z, eigvals_sorted

# Применяем ручную реализацию
Z2_manual, eigvals_sorted = my_pca(X_scaled, 2)

print("\nФорма Z2_manual:", Z2_manual.shape)
print("Первые 5 собственных значений:")
print(eigvals_sorted[:5])
 
# 5. PCA через sklearn


pca_sk = PCA(n_components=2)
Z2_sklearn = pca_sk.fit_transform(X_scaled)

print("\nФорма Z2_sklearn:", Z2_sklearn.shape)
print("Доля объясненной дисперсии (sklearn):")
print(pca_sk.explained_variance_ratio_)
 
# 6. Сравнение реализаций (scatter plot)
 
plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.scatter(Z2_manual[:, 0], Z2_manual[:, 1], c=y, cmap="coolwarm")
plt.title("Manual PCA")
plt.xlabel("PC1")
plt.ylabel("PC2")

plt.subplot(1, 2, 2)
plt.scatter(Z2_sklearn[:, 0], Z2_sklearn[:, 1], c=y, cmap="coolwarm")
plt.title("Sklearn PCA")
plt.xlabel("PC1")
plt.ylabel("PC2")

plt.tight_layout()
plt.show()


# 7. Scree Plot (график осыпи)
 
# Полный PCA для анализа всех компонент
Z_full, eigvals_full = my_pca(X_scaled, X_scaled.shape[1])

explained_variance_ratio = eigvals_full / np.sum(eigvals_full)

plt.figure(figsize=(8, 5))
plt.plot(range(1, len(eigvals_full)+1), eigvals_full, marker='o')
plt.title("Scree Plot")
plt.xlabel("Номер компоненты")
plt.ylabel("Собственное значение")
plt.grid()
plt.show()

# 8. Накопленная объясненная дисперсия

cumulative_variance = np.cumsum(explained_variance_ratio)

plt.figure(figsize=(8, 5))
plt.plot(range(1, len(cumulative_variance)+1), cumulative_variance, marker='o')
plt.axhline(y=0.9, color='r', linestyle='--')
plt.title("Накопленная объясненная дисперсия")
plt.xlabel("Число компонент")
plt.ylabel("Доля объясненной дисперсии")
plt.grid()
plt.show()
 
# 9. Визуализация классов в PCA пространстве

plt.figure(figsize=(8, 6))
sns.scatterplot(x=Z2_sklearn[:, 0], y=Z2_sklearn[:, 1], hue=y, palette="coolwarm")
plt.title("Breast Cancer Dataset in PCA space")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.legend(title="Class")
plt.show()