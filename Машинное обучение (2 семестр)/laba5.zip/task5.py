# ЛАБОРАТОРНАЯ РАБОТА №5 (ИСПРАВЛЕННАЯ ВЕРСИЯ)

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as T
import matplotlib.pyplot as plt
import numpy as np
import time

from torch.utils.data import DataLoader
from sklearn.metrics import confusion_matrix
import seaborn as sns

torch.manual_seed(42)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

 
# 1. CIFAR-10
 

transform = T.Compose([
    T.ToTensor(),
    T.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
])

trainset = torchvision.datasets.CIFAR10('./data', train=True, download=True, transform=transform)
testset  = torchvision.datasets.CIFAR10('./data', train=False, download=True, transform=transform)

train_loader = DataLoader(trainset, batch_size=64, shuffle=True)
test_loader  = DataLoader(testset, batch_size=64)

classes = trainset.classes

 
# 2. Визуализация
 

def show_images():
    images, labels = next(iter(train_loader))

    plt.figure(figsize=(10,4))
    for i in range(10):
        plt.subplot(2,5,i+1)
        img = images[i] / 2 + 0.5
        plt.imshow(np.transpose(img.numpy(), (1,2,0)))
        plt.title(classes[labels[i]])
        plt.axis('off')
    plt.show()

show_images()

 
# 3. CNN модель
 

class CNN(nn.Module):
    def __init__(self):
        super().__init__()

        self.features = nn.Sequential(
            nn.Conv2d(3,32,3,padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(),
            nn.MaxPool2d(2,2),

            nn.Conv2d(32,64,3,padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(2,2)
        )

        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(64*8*8,512),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(512,10)
        )

    def forward(self,x):
        return self.classifier(self.features(x))

model = CNN().to(device)

 
# 4. Общая функция оценки (FIX!)
 

def evaluate(model, loader):
    model.eval()
    correct = 0
    total = 0

    with torch.no_grad():
        for x,y in loader:
            x,y = x.to(device), y.to(device)
            out = model(x)
            _, pred = torch.max(out,1)
            total += y.size(0)
            correct += (pred==y).sum().item()

    return 100*correct/total

 
# 5. Обучение CNN
 

criterion = nn.CrossEntropyLoss()
optimizer = optim.AdamW(model.parameters(), lr=1e-3)

train_losses = []
test_accs = []

print("\nОбучение CNN")
start_time = time.time()

for epoch in range(15):
    model.train()
    total_loss = 0

    for x,y in train_loader:
        x,y = x.to(device), y.to(device)

        out = model(x)
        loss = criterion(out,y)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        total_loss += loss.item()

    avg_loss = total_loss / len(train_loader)
    acc = evaluate(model, test_loader)

    train_losses.append(avg_loss)
    test_accs.append(acc)

    print(f"Epoch {epoch+1}: Loss={avg_loss:.4f}, Acc={acc:.2f}%")

cnn_time = time.time() - start_time

 
# 6. Confusion Matrix
 

all_preds = []
all_labels = []

model.eval()
with torch.no_grad():
    for x,y in test_loader:
        x = x.to(device)
        out = model(x)
        _, pred = torch.max(out,1)

        all_preds.extend(pred.cpu().numpy())
        all_labels.extend(y.numpy())

cm = confusion_matrix(all_labels, all_preds)

plt.figure(figsize=(8,6))
sns.heatmap(cm)
plt.title("Confusion Matrix (CNN)")
plt.show()

 
# 7. Transfer Learning (ResNet)
 

from torchvision import models

transform_resnet = T.Compose([
    T.Resize(224),
    T.ToTensor(),
    T.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
])

trainset_r = torchvision.datasets.CIFAR10('./data', train=True, download=True, transform=transform_resnet)
testset_r  = torchvision.datasets.CIFAR10('./data', train=False, download=True, transform=transform_resnet)

train_loader_r = DataLoader(trainset_r, batch_size=64, shuffle=True)
test_loader_r  = DataLoader(testset_r, batch_size=64)

model_resnet = models.resnet18(weights=models.ResNet18_Weights.DEFAULT)
model_resnet.fc = nn.Linear(model_resnet.fc.in_features,10)
model_resnet = model_resnet.to(device)

 
# Feature Extraction
 

for p in model_resnet.parameters():
    p.requires_grad = False

for p in model_resnet.fc.parameters():
    p.requires_grad = True

optimizer = optim.AdamW(model_resnet.fc.parameters(), lr=1e-3)

print("\nFeature Extraction")

for epoch in range(5):
    model_resnet.train()

    for x,y in train_loader_r:
        x,y = x.to(device), y.to(device)

        out = model_resnet(x)
        loss = criterion(out,y)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    acc = evaluate(model_resnet, test_loader_r)
    print(f"Epoch {epoch+1}, Acc={acc:.2f}%")

 
# Fine-Tuning
 

for p in model_resnet.parameters():
    p.requires_grad = True

optimizer = optim.AdamW(model_resnet.parameters(), lr=1e-4)

print("\nFine-Tuning")

for epoch in range(10):
    model_resnet.train()

    for x,y in train_loader_r:
        x,y = x.to(device), y.to(device)

        out = model_resnet(x)
        loss = criterion(out,y)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

    acc = evaluate(model_resnet, test_loader_r)
    print(f"Epoch {epoch+1}, Acc={acc:.2f}%")

 
# 8. Графики
 

plt.plot(train_losses)
plt.title("Train Loss (CNN)")
plt.show()

plt.plot(test_accs)
plt.title("Test Accuracy (CNN)")
plt.show()

 
# 9. Итог
 

print("\nИТОГ:")
print(f"CNN время обучения: {cnn_time:.2f} сек")